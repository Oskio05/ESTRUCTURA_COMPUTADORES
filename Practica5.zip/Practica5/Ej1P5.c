#include <stdio.h>

int NumDivisores(int num);
int main () {
int num,divisores;
printf("Introduzca un número positivo: ");
scanf(" %d", &num);
while(num<0){
    printf("ERROR, NO ES POSITIVO\n");
    printf("Introduzca un número positivo: ");
    scanf("%d",&num);
}
//Llamada a la función
divisores=calcula_divisores(num);
printf("Los divisores que tiene ese número son: %d", divisores);
return 0;
}
int calcula_divisores(int num){
int divisores=0;
for (int i=num; i>=1; i--){
    if(num%i==0){
        divisores=divisores+1;
    }
}
return divisores;
}