#include <stdio.h>

int calcula_si_es_primo(int num);
int NumDivisores(int num);
int main () {
int num,resultado;
printf("Introduzca un número positivo: ");
scanf(" %d", &num);
while(num<0){
    printf("ERROR NO ES POSITIVO\n");
    printf("Escribe un número positivo: ");
    scanf(" %d", &num);
}
resultado=calcula_si_es_primo(num);
printf("Si es 1 es primo si es 0 no: %d", resultado);
return 0;
}
int calcula_si_es_primo(int num){
    int total=1;
    NumDivisores(num);
    if(NumDivisores(num)<2){
        total=total;
    }
    else{
        total=total-1;
    }
    return total;
}
int NumDivisores(int num){
    int divisores=0;
    for(int i=1; i<=num; i++){
        if(num%i==0){
            divisores++;                
        }
    }
    return divisores;    
}