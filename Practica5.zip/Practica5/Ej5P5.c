#include <stdio.h>

int calcula_unos(int num);
int main() {
    int num, unos;
    printf("Introduzca un número positivo: ");
    scanf("%d", &num);
    while (num < 0){
        printf("ERROR: El número debe ser positivo.\n");
        printf("Introduzca un número positivo: ");
        scanf("%d", &num);
    }
    unos = calcula_unos(num);
    printf("El número de 1's en la representación binaria es: %d", unos);
    return 0;
}

int calcula_unos(int num) {
    int contador = 0;
    while (num != 0) {
        if (num & 1) {
            contador++;
        }
        num >>= 1; // Desplazar el número una posición a la derecha
    }
    return contador;
}
