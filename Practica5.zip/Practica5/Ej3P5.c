#include <stdio.h>
#include <math.h>

int menu(int num);
int cal_med(int num1,int num2,int num3, int num4, int num5);
int cal_des(int num1,int num2,int num3, int num4, int num5);

int main() {
    int opcion, num, num1, num2, num3, num4, num5,resultado;
    opcion=menu(num);
    if(opcion==1){
        resultado=cal_med(num1, num2, num3, num4, num5);
        printf("La media de esos 5 números es: %.2d", resultado);
    }
    if(opcion==2){    
        resultado=cal_des(num1, num2, num3, num4, num5);
        printf("La desviación típica de esos 5 números es: %.2d", resultado);
    }
    if(opcion==3){
        printf("Saliendo del programa.");
    }
}

int menu(int num){
    printf("--MENU--\n");
    printf("1. Calcular la media de los números: \n2. Calcular la desviación tipica de los números: \n3. Salir: \n");
    scanf("%d", &num);
    if(num!=1 && num!=2 && num!=3){
        printf("ERROR, el valor no corresponde a ninguna opción.");
        scanf("%d", &num);
    return num;
    }

}
int cal_med(int num1,int num2,int num3, int num4, int num5) {
        printf("Escribe el primer valor: ");
        scanf("%d", &num1);
        printf("Escribe el segundo valor: ");
        scanf("%d", &num2);
        printf("Escribe el tercer valor: ");
        scanf("%d", &num3);
        printf("Escribe el cuarto valor: ");
        scanf("%d", &num4);
        printf("Escribe el quinto valor: ");
        scanf("%d", &num5);
        int media=(num1+num2+num3+num4+num5)/5;
        return media;
}
int cal_des(int num1,int num2,int num3, int num4, int num5) {
        printf("Escribe el primer valor: ");
        scanf("%d", &num1);
        printf("Escribe el segundo valor: ");
        scanf("%d", &num2);
        printf("Escribe el tercer valor: ");
        scanf("%d", &num3);
        printf("Escribe el cuarto valor: ");
        scanf("%d", &num4);
        printf("Escribe el quinto valor: ");
        scanf("%d", &num5);
        int media=(num1+num2+num3+num4+num5)/5;
        int sumDifCuad= pow(num1 -media,2) + pow(num2 - media, 2) + pow(num3 - media, 2) + pow(num4 - media, 2) + pow(num5 - media, 2);
        int medSumDifCuad= sumDifCuad/5;
        int desviacion= sqrt(medSumDifCuad);
        return desviacion;
}