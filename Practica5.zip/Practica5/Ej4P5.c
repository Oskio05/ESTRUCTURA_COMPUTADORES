#include <stdio.h>

int calcula_multiplos_intervalo(int num1,int num2,int num3);
int main () {
int num1,num2,num3;
printf("Escribe al número más pequeño del intervalo: ");
scanf("%d", &num1);
printf("Escribe al número más grande del intervalo: ");
scanf("%d", &num2);
printf("Escribe el número del que queramos sacar sus múltiplos: ");
scanf("%d", &num3);
while(num1>num2){
    printf("ERROR, el número 1 es MAYOR al número 2.\n");
    printf("Escribe al número más pequeño del intervalo: ");
    scanf("%d", &num1);
    printf("Escribe al número más grande del intervalo: ");
    scanf("%d", &num2);
    }
    calcula_multiplos_intervalo(num1,num2,num3);
return 0;
}
int calcula_multiplos_intervalo(int num1,int num2,int num3){
    for(int i=num1; i<num2; i++){
        if(i%num3==0){
            printf("%d ", i);
        }
    } 
}