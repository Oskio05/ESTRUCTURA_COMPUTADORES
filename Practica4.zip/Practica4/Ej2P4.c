#include <stdio.h>

int suma_n_primeros_nums(int num);

int main() {
    int num, suma , total;
    printf("Introduzca desde que numero empezar a sumar: ");
    scanf("%d", &num);
    if (num>0){   
        total=suma_n_primeros_nums(num);
        printf("La suma total es %.2d", total);
    }
    return 0;
}

int suma_n_primeros_nums(int num) {
    int suma=0;
    for(int i=num; i>0; i--){
        suma +=i;
    }
    return suma;
}