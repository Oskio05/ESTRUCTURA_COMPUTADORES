#include <stdio.h>

float calcularNota(float a);

int main() {
    float a,nota;
    printf("Introduzca la nota: ");
    scanf("%f", &a);
    
    // Llamada a la función. Deja el resultado en area
    nota = calcularNota(a);
    if(nota>0 && nota<5){
        printf("Tu nota es suspenso");
    }
    if(nota>=5 && nota<=7){
        printf("Tu nota es aprobado");
    }
    if(nota>=7&& nota<8){
        printf("Tu nota es notable");
    }
    if(nota>=9 && nota<10){
        printf("Tu nota es sobresaliente");
    }
    return 0;
}

float calcularNota(float a) {
    float resultado;
    resultado = a;
    return resultado;
}