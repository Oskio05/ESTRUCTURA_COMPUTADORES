#include <stdio.h>

int potencia(int base, int exp);

int main() {
    int base, exp , resultado;
    printf("Introduzca la base de la potencia: ");
    scanf("%d", &base);
    printf("Introduzca el exponente de la potencia: ");
    scanf("%d", &exp);
    while(base<0 || exp<0){
        printf("ERROR, uno de los valores no es positivo, reescribalo.\n");
        printf("Introduzca la base de la potencia: ");
        scanf("%d", &base);
        printf("Introduzca el exponente de la potencia: ");
        scanf("%d", &exp);
    }
        resultado=potencia(base,exp);
        printf("La suma total es %.2d", resultado);
    return 0;
}

int potencia(int base, int exp) {
    int total=1;
    while(exp>0){
        total=total*base;
        exp--;
    }
    return total;
}