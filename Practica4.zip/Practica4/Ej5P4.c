#include <stdio.h>

int imprime_pares_intervalo(int num1,int num2);

int main() {
    int num1,num2;
    printf("Introduzca desde que número empezar: ");
    scanf("%d", &num1);
    printf("Introduzca un segundo número (mayor al primero): ");
    scanf("%d", &num2);
    while(num2<num1){
        printf("ERROR, el primer nº DEBE ser menor al segundo.\n");
        printf("Introduzca otro primer número: ");
        scanf("%d", &num1);
        printf("Introduzca un segundo número (mayor al primero): ");
        scanf("%d", &num2);
    }
    imprime_pares_intervalo(num1,num2);
    return 0;
}
int imprime_pares_intervalo(int num1,int num2){
    for(int i=num2-1; i>=num1+1; i--){
        if(i%2==0){
            printf(" %d", i);
        }
    }
}