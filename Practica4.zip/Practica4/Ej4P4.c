#include <stdio.h>

int menu(int num);
int volumen_cono(int anchura,int fondo,int alto);
int volumen_ortoedro(int ancho,int longitud,int altura);

int main() {
    int opcion,num,ancho,anchura,longitud,fondo,alto,altura,resultado;
    opcion=menu(num);
    if(opcion==1){
        resultado=volumen_cono(anchura,longitud,alto);
        printf("El volumen del cono es: %.2d", resultado);
    }
    if(opcion==2){    
        resultado=volumen_ortoedro(ancho,fondo,altura);
        printf("El volumen del ortoedro es: %.2d", resultado);
    }
    if(opcion==3){
        printf("Saliendo del programa.");
    }
}

int menu(int num){
    printf("1. Calcular el volumen de un cono: \n2. Calcular el volumen de un ortoedro: \n3. Salir: \n");
    scanf("%d", &num);
    if(num!=1 && num!=2 && num!=3){
        printf("ERROR, el valor no corresponde a ninguna opción.");
        scanf("%d", &num);
    return num;
    }

}
int volumen_cono(int anchura,int longitud,int alto) {
        printf("Escribe el valor del ancho del cono: ");
        scanf("%d", &anchura);
        printf("Escribe el valor de la longitud del cono: ");
        scanf("%d", &longitud);
        printf("Escribe el valor de su altura: ");
        scanf("%d", &alto);
        int volumen=anchura*longitud*alto;
        return volumen;
}
int volumen_ortoedro(int ancho,int fondo,int altura) {
        printf("Escribe el valor del ancho del ortoedro: ");
        scanf("%d", &ancho);
        printf("Escribe el valor de la fondo del ortoedro: ");
        scanf("%d", &fondo);
        printf("Escribe el valor de su altura: ");
        scanf("%d", &altura);
        int volumen=ancho*fondo*altura;
        return volumen;
}