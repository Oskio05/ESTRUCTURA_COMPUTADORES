#include <stdio.h>

int factorial(int num);

int main() {
    int num,f;
    printf("Introduzca desde que número empezar: ");
    scanf("%d", &num);
    while(num<0){
        printf("ERROR, los números negativos no tienen factorial.\n");
        printf("Introduzca otro número: ");
        scanf("%d", &num);
    }
    f=factorial(num);
    printf("El factorial del %d es %d", num, f);
    return 0;
}
int factorial(int num){
    int total=1;
    while(num>0){
        total=total*num;
        num=num-1;
    }
    return total;
    }