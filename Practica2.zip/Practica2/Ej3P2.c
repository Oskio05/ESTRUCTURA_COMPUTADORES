#include <stdio.h>

int main ()
{
    float Celsius, Farenheit;
    printf("Escribe un número de grados Celsius: ");
    scanf("%f", &Celsius);
    Farenheit= Celsius+32;
    printf("En grados Farenheit son: ");
    printf("%.2f", Farenheit);
    printf("\n Fin del algoritmo");

    return 0;
}