#include <stdio.h>

int main ()
{
    int Num;
    printf("Escribe un número: ");
    scanf("%d", &Num);
    printf("El dato introducido es: %d \nFin del algoritmo", Num);
    return 0;
}