#include <stdio.h>

int main ()
{
    float Km, Millas, Yardas, Pies;
    printf("Escribe un número de kilómetros: ");
    scanf("%f", &Km);
    Millas= Km /1.60;
    Pies= Km * 100000 / 30.48 ;
    Yardas= Km * 10000 / 91.44 ;
    printf("Las millas son: ");
    printf("%f", Millas);
    printf("\n Los pies son: ");
    printf("%f", Pies);
    printf("\n Las yardas son: ");
    printf("%f", Yardas);
    printf("\n Fin del algoritmo");

    return 0;
}