#suma_n_numeros.py
num=float(input('Introduce un número: '))
def suma_n_primeros_nums(num):
    suma=0
    while(num>=0):
        suma=suma+num
        num=num-1
    return suma
while(num < 0):
    print('ERROR: El número NO es positivo')
    num = float(input('Escribe un nuevo número: '))
resultado = suma_n_primeros_nums(num)
print("La suma de los números introducidos es:", resultado)