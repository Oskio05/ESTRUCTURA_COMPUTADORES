#Calcula_nota.py
num=float(input('Introduce tu nota: '))
def calcula_nota(num):
    
    if (num>0 and num<5):
        print('Estas suspenso')
    if (num>=5 and num<7):
        print('Estas aprobado')
    if (num>=7 and num<9):
        print('Tienes notable')
    if (num>=9 and num<=10):
        print('Sobresaliente')
while(num < 0 or num > 10):
    print('ERROR: La nota debe estar en el rango de 0 a 10')
    num = float(input('Escribe un nuevo número: '))
calcula_nota(num)