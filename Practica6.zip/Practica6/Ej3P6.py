#potencia.py
num1=float(input('Introduce el número positivo del que quieras conocer la potencia: '))
num2=float(input('Introduce el valor del exponente: '))
def potencia(num1,num2):
    total=num1**num2
    return total
while(num1 < 0 or num2<0):
    print('ERROR: Uno de los dos números NO es positivo')
    num1=float(input('Cambia la base: '))
    num2=float(input('Cambia el exponente: '))
resultado = potencia(num1,num2)
print("El valor de la potencia es:", resultado)