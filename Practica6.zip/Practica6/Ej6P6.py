#factorial.py
n=int(input('Escriba un número del que desee saber su factorial: '))
while(n<0):
    print('ERROR, NO existen los factoriales negativos.')
    n=int(input('Vuelva a escribir un número: '))
def factorial(n):
    total=1
    while(n>0):
        total=total*n
        n=n-1
    return total
resultado=factorial(n)
print('El factorial del ', n ,' es ', resultado)