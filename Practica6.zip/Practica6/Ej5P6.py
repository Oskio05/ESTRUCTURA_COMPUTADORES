#pares_en_intervalo.py
num1=int(input('Escriba un número: '))
num2=int(input('Escriba otro número (debe ser mayor al primero): '))
while(num2<num1):
    print('ERROR, el segundo es MENOR al primero, cambielo.')
    num1=int(input('Vuelva a escribir un número: '))
    num2=int(input('Vuelva a escribir el segundo número (debe ser mayor al primero): '))

def imprime_pares_intervalo(num1,num2):
    for i in range(num1+1,num2-1):
        if(i%2==0):
            print(i)
imprime_pares_intervalo(num1,num2)