#volumen.py
print('MENU')
print('¿Qué desea hacer?')
num1=float(input('1. Calcular el volumen de un cono: \n2. Calcular el volumen de un ortoedro: \n3. Salir: \n'))
if(num1==1):
    ancho=float(input('Escribe el valor del ancho del cono: '))
    longitud=float(input('Escribe el valor de la longitud del cono: '))
    altura=float(input('Escribe el valor de su altura: '))
    def volumen_cono(ancho,longitud,altura):
        volumen=ancho*longitud*altura
        return volumen
    resultado=volumen_cono(ancho,longitud,altura)
    print('El volumen del cono es:', resultado)
if(num1==2):
    anchura=float(input('Escribe la anchura del ortoedro: '))
    fondo=float(input('Escribe el valor del fondo del ortoedro: '))
    alto=float(input('Escribe el alto del ortoedro: '))
    def volumen_ortoedro(anchura,fondo,alto):
        volumen=anchura*fondo*alto
        return volumen    
    resultado=volumen_ortoedro(anchura,fondo,alto)
    print('El volumen del ortoedro es:', resultado)
if(num1==3):
    print('Saliendo del programa.')
while(num1!=1 and num1!=2 and num1!=3):
    print('ERROR el valor no es ninguna de las opciones')
    print('¿Qué desea hacer?')
    num1=float(input('1. Calcular el volumen de un cono: \n2. Calcular el volumen de un ortoedro: \n3. Salir: \n'))

